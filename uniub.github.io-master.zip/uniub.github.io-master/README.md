<p align="center">
<kbd style="padding:10px;">
<img src="https://avatars.githubusercontent.com/u/115511537" width="150px" height="150px">
</kbd>
</p>
<h1 align="center">Uni UB</h1>

<a href="https://discord.gg/nX6sWSa9HE"><img height="30px" src="https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white"><img></a>

# Description
**UniUB (Universal Unblocker) Is an unblocked games website by me (Jobi#8313) :D**
**Its actively being worked on, with updates at minimum every week :)**
# Features
- **200+ Proxies**
- **50+ Games**
- **10+ Ways to disable extension(s)**
- **30+ Emulators.**
- **1 App (More to be added later)**
# Modding
**How to start the server without pushing**
## Requirements
- **Python 3 (Or higher) installed.**
- **Google chrome (For windows)**
- **Git is installed**
## On Windows
- **Fork the repo (On wsl or git cli you can use <kbd>git clone https://uniub.github.io</kbd>)**
- **Go into the newly created folder.**
- **Via file explorer, double click the "startserver.bat" file. (Via cmd, run <kbd>startserver.bat</kbd>)**
## On Linux
- **Fork the repo by running <kbd>sudo git clone https://uniub.github.io</kbd>**
- **Cd into the repo by doing <kbd>cd uniub.github.io</kbd>**
- **Run <kbd>sh ./startserver.sh</kbd>**
## Troubleshooting
- **Make sure you have a browser installed (Specifically chrome if your on windows.)**
- **Make sure you have a version of python installed that supports http.server**
- **Make sure you have git instslled**
- **Make sure your in the right directory**
